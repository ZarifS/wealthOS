import axios from 'axios';
import { getLocalStorageWithExpiry, getAPIServerURL } from '../utils';
import { TOKEN_KEY } from './authService';
const API_URL = getAPIServerURL + '/user';

const getUser = async () => {
    const token = getLocalStorageWithExpiry(TOKEN_KEY);

    if (!token) throw new Error('No token found.');

    const response = await axios.get(API_URL + '/user', {
        Headers: {
            Authorization: `Bearer ${token}`,
        }
    });
    if (response.data.token) {
      setLocalStorageWithExpiry(TOKEN_KEY, response.data.token, TOKEN_EXPIRY);
    }
    return response.data;
  };